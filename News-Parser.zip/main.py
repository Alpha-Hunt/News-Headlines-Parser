import sys
from PyQt5 import QtCore, QtGui, QtWidgets
from PyQt5.QtCore import *
from PyQt5.QtWebEngineWidgets import *
from PyQt5.QtWidgets import *
from PyQt5.QtGui import QIcon
import bs4
from bs4 import BeautifulSoup as soup
from urllib.request import urlopen
import webbrowser


class window(QMainWindow):


    def __init__(self):
        super(window, self).__init__()
        self.setGeometry(1, 31, 482, 655)
        self.setWindowTitle('pyqt5 Tut')
        self.setWindowIcon(QIcon('pic.png'))

        choicex = QMessageBox.question(self, 'Message',
                                     "We want to load news", QMessageBox.Yes |
                                     QMessageBox.No)

        if choicex == QMessageBox.Yes:
            self.home
        else:
            sys.exit()

        quit = QAction('&Quit', self)
        quit.setShortcut('Ctrl+Q')
        quit.setStatusTip('leave the app')
        quit.triggered.connect(self.close)

        refresh = QAction('&Refresh', self)
        refresh.setShortcut('Ctrl+R')
        refresh.setStatusTip('Refresh')
        refresh.triggered.connect(self.initUI)

        instructions=QAction('&Instructions',self)
        instructions.setShortcut('Ctrl+H')
        instructions.setStatusTip('Help Me!')
        instructions.triggered.connect(self.help)

        refresh = QAction(QIcon('refresh.png'), 'Refresh News', self)
        refresh.triggered.connect(self.initUI)

        quit = QAction(QIcon('quit.png'), 'Quit News', self)
        quit.triggered.connect(self.close)

        self.statusBar()

        mainMenu = self.menuBar()

        fileMenu = mainMenu.addMenu('&File')
        HelpMenu = mainMenu.addMenu('&Help')

        HelpMenu.addAction(instructions)
        fileMenu.addAction(refresh)
        fileMenu.addAction(quit)

        self.toolBar = self.addToolBar('toolbar')
        self.toolBar.addAction(refresh)
        self.toolBar.addAction(quit)
        self.toolBar.setIconSize(QtCore.QSize(32, 32))
        self.toolBar.setMovable(False)
        self.home()
        self.initUI()

    def initUI(self):
        n,newslist,link=self.newsload()
        self.scroll = QScrollArea()             # Scroll Area which contains the widgets, set as the centralWidget
        self.widget = QWidget()                 # Widget that contains the collection of Vertical Box
        self.vbox = QVBoxLayout()               # The Vertical Box that contains the Horizontal Boxes of  labels and buttons

        font = QtGui.QFont()
        font.setBold(False)
        font.setFamily("Comic Sans MS")
        font.setPointSize(15)

        self.scrollAreaWidgetContents = QtWidgets.QWidget()

        for i in range(0,38):

            object = QLabel('xxx')
            title = QLabel('xxx')
            object.setOpenExternalLinks(True)

            urlLink="<a href=\""+link[i]+"\" style=\"text-decoration:None;font-size:25px;color: black;\">Read More...</a>"

            title.setText(str(i+1)+" || "+newslist[i])
            object.setText(urlLink)

            object.setFont(font)
            title.setFont(font)

            object.setObjectName("some")
            object.setStyleSheet(open('style.css').read())

            object.setMinimumSize(QtCore.QSize(0, 20))
            title.setMinimumSize(QtCore.QSize(0, 150))
            object.setMaximumWidth(470)
            object.setMaximumHeight(700)
            object.setWordWrap(True)
            object.setAlignment(QtCore.Qt.AlignHCenter|QtCore.Qt.AlignTop)
            title.setWordWrap(True)
            title.setAlignment(QtCore.Qt.AlignHCenter|QtCore.Qt.AlignTop)
            title.setStyleSheet(open('style.css').read())

            self.vbox.addWidget(title)
            self.vbox.addWidget(object)

            hr = QtWidgets.QFrame(self.scrollAreaWidgetContents)
            hr.setFont(font)
            hr.setFrameShadow(QtWidgets.QFrame.Plain)
            hr.setFrameShape(QtWidgets.QFrame.HLine)
            self.vbox.addWidget(hr)

        self.widget.setLayout(self.vbox)

        #Scroll Area Properties
        self.scroll.setVerticalScrollBarPolicy(Qt.ScrollBarAlwaysOn)
        self.scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        self.scroll.setWidgetResizable(True)
        self.scroll.setWidget(self.widget)

        self.setCentralWidget(self.scroll)

        self.setFixedSize(QSize(482, 700))

        self.setWindowTitle('Minimal News')
        self.show()
        return

    def home(self):

        widget = QWidget()
        layout = QVBoxLayout(widget)
        layout.setAlignment(Qt.AlignTop)
        self.show()

    def close(self):
        choice = QMessageBox.question(self, 'Message',
                                     "Are you sure to quit?", QMessageBox.Yes |
                                     QMessageBox.No)

        if choice == QMessageBox.Yes:
            print('quit application')
            sys.exit()
        else:
            pass

    def help(self):
        print('Help')
        QMessageBox.question(self, "Help", "This Is Help Page", QMessageBox.Ok)

    def newsload(self):

        news_url="https://news.google.com/news/rss"
        try:
            Client=urlopen(news_url)
            xml_page=Client.read()
            Client.close()

            soup_page=soup(xml_page,"xml")
            news_list=soup_page.findAll("item")
            # Print news title, url and publish date
            newstitle=[]
            newslink=[]
            newsdate=[]
            num=0
            for news in news_list:
                num+=1
            n=0
            for news in news_list:
                newstitle.append(news.title.text)
                newslink.append(news.link.text)
                newsdate.append(news.pubDate.text)
                n+=1
            return n,newstitle,newslink
        except:
            interneterr(self)

def interneterr(self):
            print('check Your internet connection and try again')
            choice =QMessageBox.question(self, "Error", "check Your internet connection and try again", QMessageBox.Ok)
            if choice == QMessageBox.Ok:
                print('quit application')
                sys.exit()

def run():
    app = QApplication(sys.argv)
    Gui = window()
    sys.exit(app.exec_())

run()
